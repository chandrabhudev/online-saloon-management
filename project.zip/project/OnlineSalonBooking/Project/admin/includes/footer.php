<!--footer-->
    <div class="footer">
       <p>&copy;  MS Admin Panel.</p>
    </div>
        <!--//footer-->