How to run the Beauty Palour Management System (BPMS) Project

1. Download the zip file

2. Extract the file and copy bpms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name bpmsdb

6. Import bpmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/bpms (frontend)

Credential for admin panel :

Username: admin
Password: Test@123